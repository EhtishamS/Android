package com.example.es21_drawer_avanzato;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class Activity_cs extends AppCompatActivity {
    TextView errore;

    double capitale;
    double tasso;
    double anno;
    double mese;
    double giorno;
    double montante;

    ArrayList<EditText> campi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cs);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Capitalizzazione Semplice");

        errore = findViewById(R.id.errore);

        campi = new ArrayList();
        campi.add((EditText) findViewById(R.id.capitale_cs)); // capitale
        campi.add((EditText) findViewById(R.id.tasso_cs)); // tasso interesse
        campi.add((EditText) findViewById(R.id.anno_cs)); // numero di anni
        campi.add((EditText) findViewById(R.id.mese_cs)); // numero di mesi
        campi.add((EditText) findViewById(R.id.giorno_cs)); // numero di giori
        campi.add((EditText) findViewById(R.id.montante_cs)); // montante
    }

    public void calcola(View v) {
        if(isErrorMade())
            return;

        if(campi.get(0).getText().toString().isEmpty()){
            try{
                anno = Double.parseDouble(String.valueOf(campi.get(2).getText()));
                mese = Double.parseDouble(String.valueOf(campi.get(3).getText()));
                giorno = Double.parseDouble(String.valueOf(campi.get(4).getText()));

                anno += (mese/12);
                anno += (giorno/360); // tempo totale in anni

                tasso = ((Double.parseDouble(String.valueOf(campi.get(1).getText())) / 100)*anno)+1;

                montante = Double.parseDouble(String.valueOf(campi.get(5).getText()));

                capitale = montante/tasso;

                campi.get(0).setText(""+capitale);
            }catch (NumberFormatException e){
                e.printStackTrace();
            }
        } else if(campi.get(1).getText().toString().isEmpty()){
            try{
                anno = Double.parseDouble(String.valueOf(campi.get(2).getText()));
                mese = Double.parseDouble(String.valueOf(campi.get(3).getText()));
                giorno = Double.parseDouble(String.valueOf(campi.get(4).getText()));

                anno += (mese/12);
                anno += (giorno/360); // tempo totale in anni

                montante = Double.parseDouble(String.valueOf(campi.get(5).getText()));
                capitale = Double.parseDouble(String.valueOf(campi.get(0).getText()));

                tasso = (montante-capitale)/(capitale*anno);

                campi.get(1).setText(""+Math.round(tasso*100));

//                System.out.println("capitale: " + capitale);
//                System.out.println("tasso: " + tasso);
//                System.out.println("tempo: " + anno);
//                System.out.println("Montante: " + montante);

            }catch (NumberFormatException e){
                e.printStackTrace();
            }
        } else if(campi.get(5).getText().toString().isEmpty()){
            try{
                anno = Double.parseDouble(String.valueOf(campi.get(2).getText()));
                mese = Double.parseDouble(String.valueOf(campi.get(3).getText()));
                giorno = Double.parseDouble(String.valueOf(campi.get(4).getText()));

                anno += (mese/12);
                anno += (giorno/360); // tempo totale in anni

                tasso = ((Double.parseDouble(String.valueOf(campi.get(1).getText())) / 100)*anno)+1;

                capitale = Double.parseDouble(String.valueOf(campi.get(0).getText()));

                montante = capitale * tasso;

                campi.get(5).setText(""+montante);
            }catch (NumberFormatException e){
                e.printStackTrace();
            }
        } else {
            try{
                montante = Double.parseDouble(String.valueOf(campi.get(5).getText()));
                capitale = Double.parseDouble(String.valueOf(campi.get(0).getText()));
                tasso = (Double.parseDouble(String.valueOf(campi.get(1).getText())) / 100)*capitale;

                anno = (montante-capitale)/tasso;

                mese = (anno - Math.floor(anno))*12;
                anno = Math.floor(anno);
                giorno = Math.floor((mese - Math.floor(mese))*30);
                mese = Math.floor(mese);

                campi.get(2).setText(""+(int) anno);
                campi.get(3).setText(""+(int) mese);
                campi.get(4).setText(""+(int) giorno);
            }catch (NumberFormatException e){
                e.printStackTrace();
            }
        }
    }

    public boolean isErrorMade(){
        int contEmpty = 0;

        if(campi.get(2).getText().toString().isEmpty()|| // se anche uno è vuoto svuoto tutto io
                campi.get(3).getText().toString().isEmpty()||
                campi.get(4).getText().toString().isEmpty()){

            campi.get(2).setText("");
            campi.get(3).setText("");
            campi.get(4).setText("");

            contEmpty = 1;

            for(int i=0;i< campi.size();i++){
                if(i == 2){
                    i=4;
                } else if(campi.get(i).getText().toString().isEmpty()){
                    contEmpty++;
                }
            }
        } else {
            for(int i=0;i<campi.size();i++){
                if(campi.get(i).getText().toString().isEmpty()){
                    contEmpty++;
                }
            }
        }

        System.out.println("campi vuoti: " + contEmpty);

        if(contEmpty < 1){
            errore.setText("Almeno un campo deve essere vuoto!");
            errore.setVisibility(View.VISIBLE);
            return true;
        } else if (contEmpty > 1){
            errore.setText("Compilare almeno tre campi");
            errore.setVisibility(View.VISIBLE);
            return true;
        } else {
            errore.setVisibility(View.INVISIBLE);
        }

        return false;
    }
}
